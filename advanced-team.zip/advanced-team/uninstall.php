<?php

/**
 * @link       http://www.codeincept.com
 * @since      1.0.0
 *
 * @package    Advanced_Team
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
